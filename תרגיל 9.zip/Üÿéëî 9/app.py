from flask import Flask, render_template, redirect, request, session, url_for

app = Flask(__name__)
app.secret_key = "abc" #for session usage

usersList = [ { "name":"Liav Shabtai", "email":"liavshab@gmail.com"},
{ "name":"Omer Shilo", "email":"omer2020@walla.com" },
{ "name":"Michael Lewis", "email":"michael@fame.com" } ]

@app.route('/')
def index():
	greeting = ""
	if "greeting" in session:
		greeting = session["greeting"]
	return render_template('cv_Ira_Tokman.html', greeting=greeting)

@app.route('/<file>')
def load_any_file(file):
	greeting = ""
	if "greeting" in session:
		greeting = session["greeting"]
	if file.find(".html")!=-1:
		return render_template(file, greeting=greeting)
	return redirect(url_for('static', filename=file))



@app.route('/assignment9', methods=["GET", "POST"])
def assignment9():
	listToSend = ['ira', 'lee', 'omer', 'liav']
	if request.args.get("search")!=None:
		searchVal = request.args.get("search")
		for x in usersList:
			if x["name"].find(searchVal)!=-1 or x["email"].find(searchVal)!=-1:
				listToSend.append(x)
	elif "name" in request.form:
		usersList.append({ "name":request.form["name"], "email":request.form["email"] })
		session["greeting"] = request.form["name"]
	elif "logout" in request.form:
		session.clear()

	greeting = ""
	if "greeting" in session:
		greeting = session["greeting"]
	return render_template("assignment9.html", users=listToSend, greeting=greeting)

if __name__ == '__main__':
	app.run(debug=True)
