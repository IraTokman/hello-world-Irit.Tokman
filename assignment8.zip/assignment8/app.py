from flask import Flask, render_template, redirect, url_for

app = Flask(__name__)


@app.route('/')
@app.route('/cv_Ira_Tokman')
def homePage():
    return render_template('cv_Ira_Tokman.html', show_hidden=True, len=len(FavoriteFood), FavoriteFood=FavoriteFood)


@app.route('/contact_list.html')
def contact_list():
    return render_template('contact_list.html')


#list of FavoriteFood
FavoriteFood = ["Salad", "Sushi", "Pizza", "Hamburger"]

@app.route('/assignment8')
def assignment8():
    return render_template('assignment8.html', show_hidden=False, len=len(FavoriteFood), FavoriteFood=FavoriteFood)


@app.route('/content')
def content():
    return render_template('MyBlock.html', show_hidden=False, len=len(FavoriteFood), FavoriteFood=FavoriteFood)


@app.template_filter('formatdatetime')
def format_datetime(value, format="%d %b %Y %I:%M %p"):
    """Format a date time to (Default): d Mon YYYY HH:MM P"""
    if value is None:
        return ""
    return value.strftime(format)


def format_datetime(value, format="%d %b %Y %I:%M %p"):
    """Format a date time to (Default): d Mon YYYY HH:MM P"""
    if value is None:
        return ""
    return value.strftime(format)


if __name__ == '__main__':
    app.run(debug=True)
